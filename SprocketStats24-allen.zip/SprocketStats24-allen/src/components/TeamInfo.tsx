import {
  Grid,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
} from "@mui/material";
import { useEffect, useState } from "react";
import Chart from "chart.js/auto";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  ArcElement,
  LineElement,
  PointElement,
} from "chart.js";
import { Bar, Doughnut, Line } from "react-chartjs-2";
import DataEntry from "../pages/DataEntry";

interface Sums {
  [key: string]: number;
}

ChartJS.register(
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
);

//This page could be done with loops but I am too fucking lazy and my brain is fried before comp
//Absolutely redo this page next year
function TeamInfo(props) {
  const [proportions, setProportions] = useState<Sums>({});
  const [averages, setAverages] = useState<Sums>({});
  const [list, setList] = useState<
    Array<{
      key: number;
      value: number;
    }>
  >([]);
  const [comments, setComments] = useState([]);

  var autonGrid = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
  ];

  var teleopGrid = [
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
  ];

  const [displayAutonGrid, setDAG] = useState([
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
  ]);

  const updateAutonDisplay = (x, y, val) => {
    setDAG((prevBoard) => {
      const displayAutonGrid = [...prevBoard];
      displayAutonGrid[x] = [...displayAutonGrid[x]];
      displayAutonGrid[x][y] = val;
      return displayAutonGrid;
    });
  };

  const [displayTeleopGrid, setDTG] = useState([
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0],
  ]);

  const updateTeleopDisplay = (x, y, val) => {
    setDTG((prevBoard) => {
      const displayTeleopGrid = [...prevBoard];
      displayTeleopGrid[x] = [...displayTeleopGrid[x]];
      displayTeleopGrid[x][y] = val;
      return displayTeleopGrid;
    });
  };

  const [doughnutLabel, setDLabel] = useState([]);

  const [dataType, setDataType] = useState(""); //On change components
  let matchNumber: number[] = [0, 12]; //used to test if chart works, you may deleted these

  var data = {
    //data input for the line charts
    labels: matchNumber, //x values, 1D array fitable
    datasets: [
      {
        label: "data",
        data: autonGrid, //y values, 1D array fitable
        backgroundColor: "#d89ce4",
        borderColor: "black",
        borderWidth: 1,
      },
    ],
  };
  var dataDoughnut = {
    //data input for the doughnut charts
    labels: doughnutLabel,
    datasets: [
      {
        label: "data",
        data: [2, 9], //Variables in the doughnut chart,an 1D array is fitable.
        backgroundColor: ["#d89ce4", "#88a4e2"],
        borderColor: ["black", "#d89ce4"],
        borderWidth: 1,
      },
    ],
  };

  var options = { aspectRatio: 2 }; //size of the graphs, used by both line and doughnut chart

  let handler = {
    get: function (target, name) {
      return target.hasOwnProperty(name) ? target[name] : 0;
    },
  };
  let stats = {};
  useEffect(() => {
    getTeamStats();
    console.log(props.pitEntry);
  }, []);

  function handleChange(e) {
    setDataType(e.target.value);
    console.log(dataType); //The variable dataType gets whatever the user choose in the dropdown, update eachtime the user make changes to the dropdown
    // console.log(user);
  }
  function displayingAutonGrid(row) {
    let returnVal = "";
    for (let i = 0; i < 9; i++) {
      returnVal += displayAutonGrid[row][i] + " ";
    }
    return returnVal;
  }

  function displayingTeleopGrid(row) {
    let returnVal = "";
    for (let i = 0; i < 9; i++) {
      returnVal += displayTeleopGrid[row][i] + " ";
    }
    return returnVal;
  }
  function getTeamStats() {
    let tempSum = {};
    let tempRates = {};
    let tempLists = [{}, {}]; //Casey made this function which fried my head
    let tempComments = [];

    let rates = new Proxy(tempRates, handler);
    let sums = new Proxy(tempSum, handler);
    let lists = new Proxy(tempLists, handler);
    props.matchEntries.forEach((entry) => {
      Object.keys(entry.fields).forEach((field) => {
        console.log(entry.fields[field]);
        // console.log(entry.fields); entire schema
        if (
          typeof entry.fields[field] === "object" &&
          entry.fields[field] != null
        ) {
          Object.keys(entry.fields[field]).forEach((option) => {
            if (typeof entry.fields[field][option] === "object") {
              //checks if the first array value is an object
              // console.log(entry.fields.gridAuton);
              if (entry.fields.gridAuton) {
                autonGrid = entry.fields[field].map((num) => num);
              }
              // updates autonGrid with values of entry.fields[field]

              if (entry.fields.gridTeleop) {
                teleopGrid = entry.fields[field].map((num) => num);
              }
            }
            // console.log(entry.fields[field][option]);
            if (typeof entry.fields[field][option] === "number") {
              sums[field + option] = entry.fields[field][option];
            } else {
              sums[field + option] = 1;
            }
          });
        } else if (typeof entry.fields[field] === "number") {
          sums[field] = entry.fields[field];
        }
      });
      for (let i = 0; i < 3; i++) {
        for (let k = 0; k < 9; k++) {
          let newVal = displayAutonGrid[i][k];
          if (autonGrid[i][k] > 0) updateAutonDisplay(i, k, (newVal += 1));
          autonGrid[i][k] = 0;
        }
      }
      for (let i = 0; i < 3; i++) {
        for (let k = 0; k < 9; k++) {
          let newVal = displayTeleopGrid[i][k];
          if (teleopGrid[i][k] > 0) updateTeleopDisplay(i, k, (newVal += 1));
          teleopGrid[i][k] = 0;
        }
      }
    });
    let entryFields = props.matchEntries
      .map((entry) => {
        return entry.fields;
      })
      .filter(
        (obj) => obj.matchType !== "Practice" && !obj.markForReview.review
      );
    console.log(entryFields);
    entryFields.forEach((entry) => {
      rates["Left Community"] +=
        entry["exitCommunityAuton"] === "Yes" || entry["leftTarmac"] === "Yes\n" //IDK what these parts are for
          ? 1
          : 0;
      rates["climbed"] +=
        entry["climbed"] === "Attempted" || entry["climbed"] === "Attempted\n"
          ? 1
          : 0;
      rates["rungLow"] +=
        entry["maxRung"] === "Low" || entry["maxRung"] === "Low\n" ? 1 : 0;
      rates["rungMid"] +=
        entry["maxRung"] === "Mid" || entry["maxRung"] === "Mid\n" ? 1 : 0;
      rates["rungHigh"] +=
        entry["maxRung"] === "High" || entry["maxRung"] === "High\n" ? 1 : 0;
      rates["rungTraversal"] +=
        entry["maxRung"] === "Traversal" || entry["maxRung"] === "Traversal\n"
          ? 1
          : 0;
      rates["collectOrNo"] +=
        entry["collectOrNo"] === "Yes" || entry["collectOrNo"] === "Yes\n"
          ? 1
          : 0;

      rates["robotDefenseOrNo"] +=
        entry["robotDefenseOrNo"] === "Yes" ||
        entry["robotDefenseOrNo"] === "Yes\n"
          ? 1
          : 0;

      sums["driverSkill"] += entry.driverSkill;
      sums["robotSpeed"] += entry.robotSpeed; //These entries no longer exist, so i commented them out
      sums["defense"] += entry.defense;
      //sums["dockedSuccess"] += entry.dockedSuccess;

      // matchNumber.push(entry.matchNumber)
      // gridCompleted.push(entry.bottomRowTeleop.Cones+entry.bottomRowTeleop.Cubes+entry.middleRowTeleop.Cones+entry.middleRowTeleop.Cubes+entry.topRowTeleop.Cones+entry.topRowTeleop.Cubes)
      // console.log(matchNumber);
      // console.log(gridCompleted);
      //sums["gridAuton"] += entry.gridAuton[0][0];

      tempComments.push(entry.comments);
      doughnutLabel.push(entry.scoreOrNo);
    });
    Object.keys(rates).forEach((i) => {
      rates[i] /= entryFields.length;
    });
    Object.keys(sums).forEach((i) => {
      sums[i] /= entryFields.length;
    });
    rates = {
      ...rates,
      rungLow: rates.rungLow / rates.climbed,
      rungMid: rates.rungMid / rates.climbed,
      rungHigh: rates.rungHigh / rates.climbed,
      rungTraversal: rates.rungTraversal / rates.climbed,
    };
    setProportions(rates);
    setAverages(sums);
    setList(lists);
    setComments(tempComments);
    // console.log(rates);//Casey created these "rates" and "sums" and I do not understand their reason of existence
    // console.log(sums);
    console.log(lists);
    console.log(displayAutonGrid);
  }

  // console.log(gridAutonSuccess);

  return (
    <Grid className="py-5">
      <hr />
      <Typography variant="h4">Team {props.teamNumber}</Typography>
      <br />

      <Typography variant="h5">Average Stats</Typography>
      <br></br>
      <Typography variant="h5">Auton</Typography>
      {/* <Typography>Bottom Row Cones: {averages.bottomRowAutonCones}</Typography>
      <Typography>Bottom Row Cubes: {averages.bottomRowAutonCubes}</Typography>
      <Typography>Middle Row Cones: {averages.middleRowAutonCones}</Typography>
      <Typography>Middle Row Cubes: {averages.middleRowAutonCubes}</Typography>
      <Typography>Top Row Cones: {averages.topRowAutonCones}</Typography>
      <Typography>Top Row Cubes: {averages.topRowAutonCubes}</Typography>
      <Typography>
        chargingStationAuton: {averages.chargingStationAuton}
      </Typography>
      <Typography>
        Exited Tarmac Rate: {Math.floor(100 * proportions.exitTarmac) + "%"}
      </Typography> */}
      <Typography> Row 1 : {displayingAutonGrid(0)}</Typography>
      <Typography> Row 2 : {displayingAutonGrid(1)}</Typography>
      <Typography> Row 3 : {displayingAutonGrid(2)}</Typography>

      {/* {displayAutonGrid} */}

      {/* Everything below may be changed according to what data is needed */}
      <hr />
      <Typography> Row 1 : {displayingTeleopGrid(0)}</Typography>
      <Typography> Row 2 : {displayingTeleopGrid(1)}</Typography>
      <Typography> Row 3 : {displayingTeleopGrid(2)}</Typography>
      <hr />

      <Typography variant="h5">Endgame</Typography>
      <Typography>
        Charging Station Rate: {Math.floor(100 * proportions.climbed) + "%"}
      </Typography>

      <hr />

      <Typography variant="h5">Match Review</Typography>
      <Typography>
        Did the Robot Collect Cargo:{" "}
        {Math.floor(100 * proportions.collectOrNo) + "%"}
      </Typography>

      <Typography>Driver Skill: {averages.driverSkill}</Typography>
      <Typography>Robot Speed: {averages.robotSpeed}</Typography>
      <Typography>
        Did the Robot play Defense:{" "}
        {Math.floor(100 * proportions.robotDefenseOrNo) + "%"}
      </Typography>
      <Typography>Defense: {averages.defense}</Typography>
      <Typography>Comments: </Typography>
      {comments.map((comment) => (
        <div>
          <Typography>{comment + "\n"} </Typography>
          <br />
        </div>
      ))}
      <hr />

      <Typography variant="h5">Robot Info</Typography>
      {props.pitEntry.length > 0 ? (
        <img
          src={props.pitEntry[0].imageLink}
          style={{ width: 300, float: "left" }}
        ></img>
      ) : (
        <Typography>No image found</Typography>
      )}
      <FormControl fullWidth>
        <InputLabel id="lineChartData">Data Type</InputLabel>
        <Select
          labelId="lineChartData"
          id="lineChartData"
          value={dataType}
          label="Data Type"
          onChange={handleChange}
        >
          {/* The dropdown components, you can change the "twenty" to whatever types of graph you want */}
          <MenuItem value={"Match Type"}>Match Type</MenuItem>
          <MenuItem value={20}>Twenty</MenuItem>
          <MenuItem value={30}>Thirty</MenuItem>
        </Select>
      </FormControl>
      {/* Line Chart components */}
      <div>
        <Line id="choice" data={data} options={options}></Line>
      </div>
      {/* Doughnut chart componenets */}
      <div>
        <Doughnut data={dataDoughnut} options={options}></Doughnut>
        <Doughnut data={dataDoughnut} options={options}></Doughnut>
      </div>
    </Grid>
  );
}

export default TeamInfo;
